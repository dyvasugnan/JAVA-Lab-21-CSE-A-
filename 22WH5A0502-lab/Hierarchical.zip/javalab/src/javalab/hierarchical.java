package javalab;
import java.lang.*;

class Animal{
	void eat() {
		System.out.print("eating");
	}
}
class Dog extends Animal{
	void bark() {
		System.out.print("barking");
	}
}
class Cat extends Animal{
	void meow() {
		System.out.print("meowing..");
	}
}
class hierarchical {
	public void main(String[] args) {
		Cat c = new Cat();
		c.meow();
		c.eat();
		//c.bark();
	}
}
