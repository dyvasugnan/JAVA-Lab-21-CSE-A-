package javalab;
import java.io.*;
import java.lang.*;
import java.util.*;

class one{
	void bike() {
		System.out.println("hero");
	}
}
class Two extends one{
	void cycle() {
		System.out.println("Atluse");
	}
}
public class Inheritance{

	public static void main(String[] args) {
		Two t = new Two();
		t.bike();
		t.cycle();
		}
	}

