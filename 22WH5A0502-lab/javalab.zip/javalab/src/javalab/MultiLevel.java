package javalab;

public class MultiLevel {

	public MultiLevel() {
		// TODO Auto-generated constructor stub
	}

}
