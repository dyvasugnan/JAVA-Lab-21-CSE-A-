/**
 * 
 */
/**
 * 
 */
module javalab {
}