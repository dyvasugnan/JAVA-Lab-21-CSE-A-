package javalab;

public class Hybrid {

	public Hybrid() {
		// TODO Auto-generated constructor stub
	}

}
