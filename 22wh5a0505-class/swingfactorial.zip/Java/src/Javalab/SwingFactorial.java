package Javalab;
import javax.swing.*;
import java.awt.event.*;
public class SwingFactorial extends JFrame implements ActionListener{
                JButton b1,b2;
                JTextField n1,res;
                JLabel number,factorial;
                SwingFactorial(){
                    this.setLayout(null);
                    b1 = new JButton("Compute");
                    b2 = new JButton("Clear");
                    number= new JLabel("Number");
                    factorial = new JLabel("Factorial");
                    n1= new JTextField();
                    res = new JTextField();
                    number.setBounds(100, 100, 100, 50);
                    n1.setBounds(200, 100, 100, 50);
           
factorial.setBounds(100, 200, 100, 50);
res.setBounds(200, 200, 100, 50);
b1.setBounds(150, 300, 100, 50);
b2.setBounds(150,400,100,50);
this.add(b1);
this.add(b2);
this.add(number);

this.add(factorial);
this.add(n1);

this.add(res);
b1.addActionListener(this);
b2.addActionListener(this);
n1.addActionListener(this);

res.addActionListener(this);
                }
    public void actionPerformed(ActionEvent ae){
            String str = ae.getActionCommand();
            if(str == "Compute"){
            int i,fact=1;
int n = Integer.parseInt(n1.getText());
for(i=n;i>=1;i--){
   fact=fact*i;
   

            }
            res.setText(String.valueOf(fact));
  }
    

if(str =="Clear")
{
n1.setText("");
res.setText("");

}
    }
   
    public static void main(String[] args){
        SwingFactorial f = new SwingFactorial();
        f.setTitle("Factorial");
        f.setSize(400,400);
        f.setVisible(true);
   f.addWindowListener(new WindowAdapter() {
public void windowClosing(WindowEvent we) {
System.exit(0);
}
});
    }
}