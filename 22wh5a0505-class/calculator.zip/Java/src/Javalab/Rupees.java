package Javalab;
import java.awt.*;
import java.awt.event.*;

public class Rupees extends JFrame implements{

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
