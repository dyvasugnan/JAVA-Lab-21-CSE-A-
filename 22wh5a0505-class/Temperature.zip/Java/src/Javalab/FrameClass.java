package Javalab;
import java.awt.*;
import java.awt.event.*;

public class FrameClass extends Frame implements ActionListener{
	Button comp,clear;
	TextField num,fact;
	FrameClass(){
		this.setLayout(null);
		comp=new Button("comp");
		clear=new Button("clear");
		this.add(comp);
		this.add(clear);
		comp.addActionListener(this);
		clear.addActionListener(this);
		num=new TextField("num");
		fact=new TextField("fact");
		this.add(num);
		this.add(fact);
		num.addActionListener(this);
		fact.addActionListener(this);
	}
	public void actionPerformed(ActionEvent ae) {
		String str=ae.getActionCommand();
		if(str==comp) {
			
		int m;
		int f=1;
		for(int i=1;i<=m;i++) {
			f=f*i;
		}
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
